var nome;
var cognome;
var addBtn;
var elencoHTML;
var errore;
var erroreElenco;
var elenco = [];
var divNascondi = document.querySelector('#toggle');
var nascosto = divNascondi.style.display = 'none';
function nascondi() {
	if (divNascondi.style.display !== "none") {
		divNascondi.style.display = "none";
	  } else {
		divNascondi.style.display = "block";
	  }
}

window.addEventListener('DOMContentLoaded', init);

function init() {
	nome = document.getElementById('nome');
	cognome = document.getElementById('cognome');
	addBtn = document.getElementById('scrivi');
	elencoHTML = document.getElementById('elenco');
	errore = document.getElementById('errore');
	erroreElenco = document.getElementById('erroreElenco');
	printData();
	eventHandler();
}

function eventHandler() {
	addBtn.addEventListener('click', function () {
		controlla();
	});
}

function printData() {
	fetch('http://localhost:3000/elenco')
		.then((response) => {
			return response.json();
		})
		.then((data) => {
			elenco = data;
			if (elenco.length > 0) {
				errore.innerHTML = '';
				elencoHTML.innerHTML = '';
				elenco.map(function (element) {
					elencoHTML.innerHTML += `<li><button type="button" class="btn btn-danger me-1" onClick="elimina(${element.id})">X</button><button type="button" id="${element.id}" class="btn btn-success me-1" onClick="modifica(${element.id})"><i class="bi bi-pencil-square"></i></button>${element.nome} ${element.cognome}</li>`;
				});
			} else {
				erroreElenco.innerHTML = 'Nessun elemento presente in elenco';
			}
		});
}
async function elimina(id) {
	var utenteId = id;
	var url = 'http://localhost:3000/elenco/' + utenteId;
	let response = await fetch(url, {
		method: 'DELETE',
		headers: {
			'content-type': 'application/json;charset=utf-8',
		}
	})
};

async function modifica(id) {
	var utenteId = id;
	var url = 'http://localhost:3000/elenco/' + utenteId;
	fetch(url, {
		method: "PATCH",
		headers: {
			"Content-Type": "application/json"
		},
		body: JSON.stringify(
			{
				nome: nomeModificato.value,
				cognome: cognomeModificato.value
			}
		)
	});
};


function controlla() {
	if (nome.value != '' && cognome.value != '') {
		var data = {
			nome: nome.value,
			cognome: cognome.value,
		};
		addData(data);
	} else {
		errore.innerHTML = 'Compilare correttamente i campi!';
		return;
	}
}

async function addData(data) {
	let response = await fetch('http://localhost:3000/elenco', {
		method: 'POST',
		headers: {
			'Content-Type': 'application/json;charset=utf-8',
		},
		body: JSON.stringify(data),
	});
	clearForm();
}

function clearForm() {
	nome.value = '';
	cognome.value = '';
}
